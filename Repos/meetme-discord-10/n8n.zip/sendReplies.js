// sendReplies.js
import puppeteer from 'puppeteer';
import logger from './src/utils/logger.js';
import config from './src/config/config.js';
import { connect } from 'amqplib';
import fs from 'fs';
import { handlePopUps } from './src/services/login.js';
import { loginToMeetMe } from './src/services/login.js';

let channel; // Declare the channel variable at the top

async function initializeQueue() {
    const connection = await connect('amqp://localhost'); // Adjust the URL as necessary
    channel = await connection.createChannel();
    await channel.assertQueue('message_processed', { durable: true }); // Ensure the queue exists
}

async function fetchMessagesFromProcessed() {
    const messages = [];
    await channel.consume('meetme_processed', (msg) => {
        if (msg !== null) {
            const messageContent = JSON.parse(msg.content.toString());
            messages.push(messageContent);
            logger.info(`Fetched message: ${JSON.stringify(messageContent)}`);
            channel.ack(msg); // Acknowledge the message
        }
    }, { noAck: false });

    // Wait for a short time to allow messages to be consumed
    await new Promise(resolve => setTimeout(resolve, 1000));
    logger.info(`Total messages fetched: ${messages.length}`);
    return messages;
}

async function sendMessageToQueue(queueName, message) {
    try {
        const bufferMessage = Buffer.from(JSON.stringify(message));
        await channel.sendToQueue(queueName, bufferMessage, { persistent: true });
        logger.info(`Message sent to ${queueName}: ${JSON.stringify(message)}`);
    } catch (error) {
        logger.error(`Error sending message to queue ${queueName}: ${error.message}`);
        throw error; // Rethrow the error to handle it in requeueMessage
    }
}

async function requeueMessage(message) {
    logger.info(`Re-queuing message: ${JSON.stringify(message)}`);
    try {
        await sendMessageToQueue('message_processed', message);
        logger.info('Message requeued successfully.');
    } catch (error) {
        logger.error(`Failed to requeue message: ${error.message}`);
    }
}

export async function sendReply(page, replyText, href) {
    logger.info(`Attempting to send reply to ${href}`);
    try {
        logger.info(`Navigating to URL: ${href}`);
        if (!href || typeof href !== 'string' || !href.startsWith('http')) {
            logger.error(`Invalid URL: ${href}`);
            throw new Error('Invalid URL for navigation');
        }
        await page.goto(href, { waitUntil: 'networkidle0', timeout: 60000 });
        logger.info('Navigation to chat page completed');
        await page.type('selector-for-reply-input', replyText); // Adjust selector as needed
        await page.click('selector-for-send-button'); // Adjust selector as needed
        logger.info('Reply sent successfully');
        return true; // Indicate success
    } catch (error) {
        logger.error(`Error sending reply: ${error.message}`);
        return false; // Indicate failure
    }
}

async function sendReplies() {
    let browser;
    try {
        await initializeQueue(); // Initialize the queue before processing messages
        browser = await puppeteer.launch(); // Corrected the function call to launch a new browser instance
        const page = await browser.newPage();
        const isLoggedIn = await loginToMeetMe(browser, page, config.MEETME_USERNAME, config.MEETME_PASSWORD);
        if (!isLoggedIn) {
            throw new Error('Login failed');
        }
        try {
            await handlePopUps(page);
        } catch (popupError) {
            logger.warn(`Error handling popups: ${popupError.message}`);
        }
        await processMessages(page); // Call to process messages
    } catch (error) {
        logger.error(`Error in sendReplies: ${error.message}`);
    } finally {
        if (browser) {
            await browser.close();
        }
    }
}

export async function processMessages(page) {
    const messages = await fetchMessagesFromProcessed(); // Ensure this function is defined
    logger.info(`Fetched ${messages.length} messages from RabbitMQ.`); // Log the number of messages
    for (const message of messages) {
        logger.info(`Processing message: ${JSON.stringify(message)}`); // Log each message being processed
        const url = message.original.url; // Adjust this line based on your message structure
        if (!url || typeof url !== 'string' || !url.startsWith('http')) {
            logger.error(`Invalid or missing URL in message: ${JSON.stringify(message)}`);
            continue; // Skip this message if URL is not valid
        }
        const success = await sendReply(page, message.flowiseResponse.text, url);
        if (!success) {
            await requeueMessage(message); // Requeue the message if sending failed
        }
    }
}

sendReplies().catch(error => {
    logger.error(`Unhandled error in sendReplies: ${error.message}`);
});