import puppeteer from 'puppeteer-core';
import dotenv from 'dotenv';
import amqp from 'amqplib';
import { executablePath } from 'puppeteer';

dotenv.config({ path: './meetme_data/.env' });

const logger = console;
let messageCounter = 0;
let browser;
let page;

const TIMEOUT = 30000; // 30 seconds
const NAVIGATION_TIMEOUT = 45000; // 45 seconds
const STATE_CHECK_INTERVAL = 5000; // 5 seconds

let state = {
    isLoggedIn: false,
    currentUrl: '',
    lastActivityTime: Date.now()
};

// Define state variables
let isLoggedIn = false;
let loginAttempts = 0;
const MAX_LOGIN_ATTEMPTS = 3;

// Helper function to delay execution
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function initBrowser() {
    browser = await puppeteer.launch({
        headless: false, // Set to true in production
        defaultViewport: null,
        args: ['--start-maximized'],
        executablePath: executablePath()
    });
    page = await browser.newPage();
    await loginToMeetMe();
    return loginToMeetMe();
}

async function checkLoginStatus() {
    try {
        const currentUrl = await page.url();
        logger.info(`Checking login status on URL: ${currentUrl}`);

        if (currentUrl.includes('#meet') || currentUrl.includes('app.meetme.com') || currentUrl.includes('#chat/')) {
            logger.info('On #meet, app page, or chat page, assuming logged in');
            return true;
        }

        const loggedInSelectors = [
            '#site-nav-user-menu',
            '.site-nav-user-dropdown',
            '[data-testid="header-avatar"]',
            '.phoenix-topnav-profile-menu',
            '.phoenix-topnav-profile-menu-toggle'
        ];

        for (const selector of loggedInSelectors) {
            const element = await page.$(selector);
            if (element) {
                logger.info(`Logged in status detected (${selector} found)`);
                return true;
            }
        }

        logger.info('No logged-in indicators found, assuming not logged in');
        return false;
    } catch (error) {
        logger.error('Error checking login status:', error);
        return false;
    }
}

async function updateState() {
    if (!page) {
        logger.error('Page is undefined during state update.');
        return;
    }
    state.currentUrl = await page.url();
    state.isLoggedIn = await checkLoginStatus();
    state.lastActivityTime = Date.now();
}

async function processNextMessage() {
    try {
        const connection = await amqp.connect('amqp://localhost');
        const channel = await connection.createChannel();
        const queue = 'meetme_processed';

        await channel.assertQueue(queue, { durable: true });

        const message = await channel.get(queue, { noAck: false });
        if (message) {
            messageCounter++;
            const parsedMessage = JSON.parse(message.content.toString());
            logger.info(`[${messageCounter}] Processing message for: ${parsedMessage.original.name}`);

            // Validate message structure
            if (parsedMessage.original && parsedMessage.original.url && parsedMessage.flowiseResponse && parsedMessage.flowiseResponse.text) {
                await sendReply({
                    href: parsedMessage.original.url,
                    replyText: parsedMessage.flowiseResponse.text
                });
                channel.ack(message);
                logger.info(`[${messageCounter}] Message processed successfully`);
            } else {
                logger.error(`[${messageCounter}] Invalid message format: ${message.content.toString()}`);
                channel.nack(message, false, false); // Reject the message without requeueing
            }
        } else {
            logger.info('No messages in queue to process');
        }

        await channel.close();
        await connection.close();
    } catch (error) {
        logger.error('Error processing next message:', error);
    }
}

async function loginToMeetMe() {
    if (isLoggedIn) {
        logger.info('Already logged in. Skipping login process.');
        return true;
    }

    loginAttempts++;
    logger.info(`Starting MeetMe login process (Attempt ${loginAttempts}/${MAX_LOGIN_ATTEMPTS})`);

    try {
        await page.goto('https://www.meetme.com', { waitUntil: 'networkidle2', timeout: 60000 });
        logger.info(`Page loaded. Current URL: ${await page.url()}`);

        await handlePopUps(page);

        // Check if we're already on the beta.meetme.com page
        if (page.url().includes('beta.meetme.com')) {
            logger.info('Already on beta.meetme.com, checking login status');
            const loginSuccess = await checkLoginStatus();
            if (loginSuccess) {
                logger.info('Already logged in on beta.meetme.com');
                isLoggedIn = true;
                return true;
            }
        }

        // If not on beta.meetme.com or not logged in, proceed with login
        const loginButton = await page.waitForSelector('#marketing-header-login .btn-black', { visible: true, timeout: 30000 });
        if (!loginButton) {
            throw new Error('Login button not found');
        }
        await loginButton.click();

        logger.info('Entering credentials');
        await page.waitForSelector('#site-login-modal-email', { visible: true, timeout: 30000 });

        await page.type('#site-login-modal-email', process.env.MEETME_EMAIL);
        await page.type('#site-login-modal-password', process.env.MEETME_PASSWORD);

        logger.info('Submitting login form');
        await Promise.all([
            page.click('#site-login-modal-submit-group > button'),
            page.waitForNavigation({ waitUntil: 'networkidle0', timeout: 60000 })
        ]);

        await handlePopUps(page);

        const newUrl = await page.url();
        logger.info(`Current URL after login submission: ${newUrl}`);

        const loginSuccess = await checkLoginStatus();
        if (loginSuccess) {
            logger.info('Successfully logged in to MeetMe');
            isLoggedIn = true;
            return true;
        }

        logger.warn(`Login attempt ${loginAttempts} unsuccessful. URL does not indicate successful login.`);

        if (loginAttempts < MAX_LOGIN_ATTEMPTS) {
            logger.info(`Retrying login in 5 seconds...`);
            await new Promise(resolve => setTimeout(resolve, 5000));
            return loginToMeetMe();
        } else {
            logger.error('Max login attempts reached. Login failed.');
            return false;
        }
    } catch (error) {
        logger.error(`Error during login: ${error.message}`);
        return false;
    }
}

async function sendReply(message) {
    const { href, replyText } = message;

    if (!href) {
        logger.error(`[${messageCounter}] Missing 'href' in message. Skipping reply.`);
        return;
    }

    logger.info(`[${messageCounter}] Attempting to navigate to: ${href}`);

    for (let attempt = 1; attempt <= 5; attempt++) {
        try {
            await page.goto(href, { waitUntil: 'networkidle2', timeout: 60000 });
            logger.info(`[${messageCounter}] Navigation attempt ${attempt}: Successfully navigated to: ${href}`);

            // Wait for any content to load
            await page.waitForSelector('#global-layer-main-content', { visible: true, timeout: 30000 });

            const currentUrl = await page.url();
            logger.info(`[${messageCounter}] Current URL after waiting for content: ${currentUrl}`);

            if (currentUrl.includes('/chat') || currentUrl.includes('#chat')) {
                logger.info(`[${messageCounter}] Successfully navigated to chat page`);

                // Log the page content for debugging
                const pageContent = await page.content();
                logger.info(`[${messageCounter}] Page content: ${pageContent.substring(0, 500)}...`);

                // Wait for any input field to be visible
                const inputSelector = 'textarea, input[type="text"]';
                await page.waitForSelector(inputSelector, { visible: true, timeout: 30000 });

                // Type the reply
                await page.type(inputSelector, replyText);

                // Log the state before clicking send
                await logPageState(page);

                // Wait for any submit button to be enabled
                const buttonSelector = 'button[type="submit"], button:contains("Send")';
                await page.waitForSelector(buttonSelector, { visible: true, timeout: 10000 });

                // Click the send button using JavaScript to avoid clickability issues
                await page.evaluate((selector) => {
                    const sendButton = document.querySelector(selector);
                    if (sendButton) {
                        sendButton.click();
                    } else {
                        throw new Error('Send button not found or disabled');
                    }
                }, buttonSelector);

                // Wait for a short time to allow the message to be sent
                await new Promise(resolve => setTimeout(resolve, 2000));

                logger.info(`[${messageCounter}] Reply sent successfully`);
                return;
            } else {
                throw new Error('Failed to load chat page');
            }
        } catch (error) {
            logger.error(`[${messageCounter}] Error in sendReply (attempt ${attempt}/5): ${error.message}`);
            if (attempt === 5) {
                throw error;
            }
            await new Promise(resolve => setTimeout(resolve, 5000));
        }
    }
}

async function logPageState(currentPage) {
    if (!currentPage) {
        logger.error('logPageState called with undefined page');
        return;
    }
    try {
        const url = await currentPage.url();
        const content = await currentPage.content();
        logger.info(`Current URL: ${url}`);
        logger.info(`Page content (first 500 characters): ${content.substring(0, 500)}`);

        const buttonState = await currentPage.evaluate(() => {
            const button = document.querySelector('button[type="submit"]');
            return button ? {
                disabled: button.disabled,
                visible: button.offsetParent !== null,
                text: button.textContent.trim()
            } : 'Button not found';
        });
        logger.info(`Send button state: ${JSON.stringify(buttonState)}`);
    } catch (error) {
        logger.error(`Error in logPageState: ${error.message}`);
    }
}

async function handlePopUps(page) {
    try {
        logger.info('Handling pop-ups or overlays...');

        const selectors = [
            '#enable-push-notifications .modal-footer button.btn-primary',
            '#nav-chat > a > div > span:nth-child(1)',
            '.modal-content button.btn-primary',
            '.modal-footer button.btn-secondary',
            'button[data-testid="push-notifications-dismiss"]'
        ];

        for (const selector of selectors) {
            const element = await page.$(selector);
            if (element) {
                await element.click();
                logger.info(`Clicked on ${selector}`);
                await page.waitForTimeout(1000); // Wait for 1 second after each click
            }
        }

        logger.info('Pop-ups or overlays handled.');
    } catch (error) {
        logger.error(`Error during pop-up handling: ${error.message}`);
        // Don't throw the error, just log it
    }
}

async function handleEnableButton() {
    try {
        const enableButton = await page.evaluate(() => {
            const buttons = Array.from(document.querySelectorAll('button'));
            return buttons.find(button => button.textContent.includes('Enable'));
        });

        if (enableButton) {
            await page.evaluate((btn) => btn.click(), enableButton);
            logger.info('Clicked "Enable" button');
            await delay(2000);  // Wait for any changes after clicking Enable
            return true;
        } else {
            logger.info('No "Enable" button found. Proceeding without clicking.');
            return false;
        }
    } catch (error) {
        logger.warn('Error while handling Enable button:', error);
        return false;
    }
}

async function recreatePage() {
    try {
        if (page) await page.close();
        await delay(1000);
        page = await browser.newPage();
        logger.info('Recreated a new page instance');
    } catch (error) {
        logger.error(`Error recreating page: ${error.message}`);
    }
}

// Main execution
(async () => {
    try {
        await initBrowser();
        while (true) {
            await updateState();
            await processNextMessage();
            await delay(STATE_CHECK_INTERVAL);
        }
    } catch (error) {
        logger.error('Fatal error:', error);
        if (browser) await browser.close();
        process.exit(1);
    }
})();